<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="css/estilomenu.css"/>
</head>
<body>
    <section id="cxprincipal">
        <header id="banner">Cadastros</header>

        <nav id="cxamigo"> 
        <a href="telacadamigos.php">Cadastro amigos</a> 
        <nav id="cxamigo img"> <img src="img/amigos.jpg"> </br>
        <button onclick="window.location.href='telacadamigos.php'" style="background-color: #c3a7f8; color: white; border: none; padding: 5px 5px; text-align: center; text-decoration: none; display: inline-block; font-size: 13px; cursor: pointer; border-radius: 5px;">Tela Cadastro amigos</button> 
</nav>
</nav>
        <nav id="cxcomercio">
        <a href="telacadcomercial.php">Cadastro Comércio</a>
        <nav id="cxcomercial img"><img src="img/comercial.jpg"> </br>
        <button onclick="window.location.href='telacadcomercial.php'"style="background-color: #c3a7f8; color: white; border: none; padding: 5px 5px; text-align: center; text-decoration: none; display: inline-block; font-size: 13px; cursor: pointer; border-radius: 5px;">Tela Cadastro Comércio</button> 

</nav>
</nav>

        <nav id="cxusuario">
        <a href="telacaduser.php">Cadastro Usuário </a>
        <nav id="cxusuario img"><img src="img/usuario.png"> </br>
        <button onclick="window.location.href='telacaduser.php'"style="background-color: #c3a7f8; color: white; border: none; padding: 5px 5px; text-align: center; text-decoration: none; display: inline-block; font-size: 13px; cursor: pointer; border-radius: 5px;">Tela Cadastro Usuário</button>
        </nav>
        </nav>

        <nav id="cxconsultaamigo"></nav>
        <nav id="cxconsultacomercio"></nav>
        <nav id="cxconsultauser"></nav>
        <footer id="rodape"> Manuely Silva - Ifsp 3 info. Todos os direitos reservados. </footer>
</section>
</body>
</html>